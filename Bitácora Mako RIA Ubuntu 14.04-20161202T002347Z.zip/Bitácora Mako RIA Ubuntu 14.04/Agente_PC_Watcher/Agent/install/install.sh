#!/bin/sh

programa=/var/www/agente-pcwatcher   #HOME del programa a ejecutar
agent=$programa/install/mako_agent   #código para el demonio del agente
startup=$programa/install/startup.sh   #código para iniciar el programa
shutdown=$programa/install/shutdown.sh #código para parar el programa

cp $agent /etc/init.d/

chmod +x /etc/init.d/mako_agent -v
chmod +x $programa/target/Agent-1.0-SNAPSHOT-jar-with-dependencies.jar -v

cp $programa/install/config.properties $programa/target/config.properties

chown root.root $programa/target/Agent-1.0-SNAPSHOT-jar-with-dependencies.jar -v
chown root.root $programa/target/config.properties -v

echo 'Introduzca los siguientes valores para la configuración del sistema:'
read -p "Url: " url
read -p "Threads: " threads
read -p "Retry: " retry

echo " Actualizando url..."
sed -i -e "s,URL_AGENT,${url},g" $programa/target/config.properties
echo " Actualizando threads..."
sed -i -e "s/THREADS_AGENT/${threads}/g" $programa/target/config.properties
echo " Actualizando retry..."
sed -i -e "s/RETRY_AGENT/${retry}/g" $programa/target/config.properties

update-rc.d mako_agent defaults

service mako_agent start