#!/bin/sh

programa=/var/www/agente-pcwatcher
java -jar $programa/target/Agent-1.0-SNAPSHOT-jar-with-dependencies.jar