#!/bin/sh

proceso=`ps -ef|grep Agent-1.0-SNAPSHOT-jar-with-dependencies.jar |grep -v grep|awk '{print $2}'`
kill -9 $proceso