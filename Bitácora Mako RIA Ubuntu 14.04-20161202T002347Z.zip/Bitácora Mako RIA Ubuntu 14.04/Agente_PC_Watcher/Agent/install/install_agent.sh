#!/bin/sh

programa=/var/www/agente-pcwatcher   #HOME del programa a ejecutar
agent=$programa/install/mako_agent   #código para el demonio del agente
startup=$programa/install/startup.sh   #código para iniciar el programa
shutdown=$programa/install/shutdown.sh #código para parar el programa

cp $agent /etc/init.d/

chmod +x /etc/init.d/mako_agent -v
chmod +x $programa/target/Agent-1.0-SNAPSHOT-jar-with-dependencies.jar -v

cp $programa/install/config2.properties $programa/target/config.properties

chown root.root $programa/target/Agent-1.0-SNAPSHOT-jar-with-dependencies.jar -v
chown root.root $programa/target/config.properties -v

update-rc.d mako_agent defaults

service mako_agent start

echo "agente instalado correctamente..."