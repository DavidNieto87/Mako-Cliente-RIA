<?php

/**
 * restpcwatcher actions.
 *
 * @package    mako PMC
 * @subpackage restpcwatcher
 * @author     Isaed Martínez Borrego
 */

class restpcwatcherActions extends sfActions
{
 /**
  * Executes index action
  *
  * @param sfRequest $request A request object
  */

  private $path_log = '/var/log/mako/rest-sesiones-pc.log';

  public function executeIndex(sfWebRequest $request)
  {
      $configuration   = ProjectConfiguration::getApplicationConfiguration('frontend', $options['env'], true);
      $context         = sfContext::createInstance($configuration);
      $dispatcher      = $configuration->getEventDispatcher();

      $this->getResponse()->setContentType('application/json');
      $this->getResponse()->setHttpHeader('Access-Control-Allow-Origin', "*");
      $this->getResponse()->setHttpHeader('Access-Control-Allow-Methods',"GET, POST, OPTIONS, PUT, DELETE");
      $this->getResponse()->setHttpHeader('Access-Control-Allow-Headers',"Origin, X-Requested-With, Content-Type, Accept");

      $usernames = explode(",", $request->getParameter('username'));

      $ips = explode(",", $request->getParameter('ip'));

      /* En base a las ips recibidas se evalua cual es la existente en BD */
      $ip         = $this->obtenerIp($ips);

      if ($usernames[0] == 'no_user_found' ) {
        error_log(" La pc ".$ip." no tiene usuarios conectados \n", 3, $this->path_log);
        exit();
      }

      /* En base a los usuarios recibidos se evalua cual es el existente en BD */
      $username   = $this->obtenerUsario($usernames);
  
      if ($username == false ) {
        error_log(" NO EXISTE EL USUARIO COMO SOCIO EN LA BD LOCAL! \n", 3, $this->path_log);
        exit();
      }

      if ($ip == false ) {
        error_log(" NO EXISTE LA IP EN LA BD LOCAL! \n", 3, $this->path_log);
        exit();
      }

      $so         = $request->getParameter('so');
      $hora       = $request->getParameter('hora');
      $fecha      = $request->getParameter('fecha');
      $centro_id  = sfConfig::get('app_centro_actual_id');

      error_log("INICIA proceso para ip $ip - centroId:$centro_id a las " . date("Y-m-d H:i:s") . "\n", 3, $this->path_log);
      error_log("username = $username \n", 3, $this->path_log);
      error_log("ip       = $ip \n", 3, $this->path_log);
      error_log("so       = $so \n", 3, $this->path_log);
      error_log("hora     = $hora \n", 3, $this->path_log);
      error_log("fecha    = $fecha \n", 3, $this->path_log);

      if ($username != 'root' && $username != 'bixit' && $username != 'administrador') {
          $c = new Criteria();
          $c->add(SesionPeer::IP, $ip);
          $s = SesionPeer::doSelectOne($c);
          if ($s != null) {
               error_log(" La ip $ip tiene sesion en BD con usuario \n" . $s->getUsuario(), 3, $this->path_log);
               $usuario_en_bd = $s->getUsuario();

               if ($username != $usuario_en_bd) {
                      error_log("Socio suplantando sesion: $usuario_en_bd suplantado por $username \n", 3, $this->path_log);
                      //Eliminamos la sesion suplantada
                      $ajuste = self::obtenerSegundosACompensar($s);
                      error_log("ajusteself" . $ajuste. "\n", 3, $this->$path_log);

                      $h = self::eliminaSesion_agente($s, $ajuste);
                      $dispatcher->notify(new sfEvent($this, 'socio.logout', array('sesion_historico'       => $h)));
                      //Creamos la sesion real del suplantador
                      //Obtenemos el socio rel usuario:
                      $socio = SocioPeer::porNombreUsuario($username);
                      if ($socio == null) {
                          error_log(" NO EXISTE EL USUARIO ".$username." COMO SOCIO EN LA BD LOCAL! \n", 3, $this->path_log);
                          exit();
                      }
                      $pc = ComputadoraPeer::getPcPorIp($ip);
                      //Para evitar el caso en que las pcs tienen el tiempo desfasado 
                      //y contemplando que el PcsWatcher corre cada 5 minutos y lo mas
                      // que hay de perdida son 5 minutos mejor tomamos el tiempo del servidor local.
                      $ts     = date("Y-m-d H:i:s");
                      $sesion = SesionPeer::crearSesion($socio, $pc, $ts, $centro_id);
                      $dispatcher->notify(new sfEvent($this, 'socio.login', array('sesion' => $sesion)));
               }else{
                      $ts     = date("Y-m-d H:i:s");
                      $sesion = SesionPeer::actualizaSesion($ip, $ts);
                      error_log("Sesion normal: $usuario_en_bd \n", 3, $this->path_log);
               }
          }else{
            error_log("No existe sesion en BD para ip $ip \n", 3, $this->path_log);
            //Revisamos que tipo de usuario es, si es un usuario de staff no hacemos nada.
            $c = new Criteria();
            $c->add(UsuarioPeer::USUARIO, $username);
            $ustaff = UsuarioPeer::doSelectOne($c);
            if ($ustaff != null) {
                error_log("Usuario staff. \n", 3, $this->path_log);
                exit();
            }
            //Si no es usuario de staff buscamos si es socio
            $c = new Criteria();
            $c->add(SocioPeer::USUARIO, $username);
            $usoc = SocioPeer::doSelectOne($c);
            if ($usoc != null) {
                //Si es un socio generamos una sesion para q no se ande paseando de gorra por el centro.
                error_log("Socio de gorra. \n", 3, $this->path_log);
                $pc = ComputadoraPeer::getPcPorIp($ip);
                //Para evitar el caso en que las pcs tienen el tiempo defasado y contemplando que
                //el PcsWatcher corre cada 5 minutos y lo mas que hay de perdida son 5 minutos
                //mejor tomamos el tiempo del servidor local.
                $ts = date("Y-m-d H:i:s");
                //TODO: Contemplar el caso en que dos sesiones del mismo usuario el mismo dia se traslapan.
                error_log("Creacion de sesion con parametros: \n", 3, $this->path_log);
                error_log("socio     = $usoc \n", 3, $this->path_log);
                error_log("pc        = $pc \n", 3, $this->path_log);
                error_log("ts        = $ts \n", 3, $this->path_log);
                error_log("centro_id = $centro_id \n", 3, $this->path_log);
                $sesion = SesionPeer::crearSesion($usoc, $pc, $ts, $centro_id);
                $dispatcher->notify(new sfEvent($this, 'socio.login', array('sesion' => $sesion)));
            }else{
               error_log(" NO EXISTE EL USUARIO COMO SOCIO EN LA BD LOCAL! \n", 3, $this->path_log);
               exit();
            }
          }
     } else {
        error_log("PC Sin sesion .", 3, $this->path_log);
        //Revisamos si hay sesion en la tabla de sesiones
        $c = new Criteria();
        $c->add(SesionPeer::IP, $ip);
        $s = SesionPeer::doSelectOne($c);
        if ($s != null) {
            //Si existe una sesion la borramos para que no este consumiendo tiempo de mas.
            error_log("PC sin sesion pero con sesion en db: " . $s->getUsuario(), 3, $this->path_log);
            $ajuste = self::obtenerSegundosACompensar($s);
            //$h = SesionPeer::eliminaSesion($s, $segundos_compensacion);
            error_log("ajusteself" . $ajuste. "\n", 3, $this->$path_log);
            $h = self::eliminaSesion_agente($s, $ajuste);
            $dispatcher->notify(new sfEvent($this, 'socio.logout', array('sesion_historico' => $h)));
        }
     }

     $this->actualizaSesionesActivas($dispatcher);

    return $this->renderText(json_encode(array("code" => 200, "message" => "Sucess", "status" => true, "username" => $username, "ip" => $ip)));
  }

   /**
   * Actualiza sesion en BD basado en tiempo transcurrido desde la ultima peticion.
   * @param $configuration
   */
  private function actualizaSesionesActivas($dispatcher) {

      $datetimeactual = new DateTime('NOW');

      $c = new Criteria();
      $sesiones = SesionPeer::doSelect($c);

      foreach ($sesiones as $s) {

          $datetimebd = new DateTime($s->getUptime());
          $interval = $datetimeactual->diff($datetimebd);

          error_log($datetimeactual->format('Y-m-d H:i:s') . " IP: " . $s->getIp() . " UPTIME: " . $s->getUptime()."\n", 3, $this->path_log);
          error_log(" Minutos trancurridos desde la ultima actualizacion para ip: ".$s->getIp()." ->" . $interval->i." minutos\n", 3, $this->path_log);

          if ($interval->i >= 5){
              error_log("Se elimina sesion para " . $s->getIp()."\n", 3, $this->path_log);
              $ajuste = self::obtenerSegundosACompensar($s);

              $h = self::eliminaSesion_agente($s, $ajuste);
              $dispatcher->notify(new sfEvent($this, 'socio.logout', array('sesion_historico' => $h)));
          }
      }

    }

   /**
   * Obtiene segundos compensacion para el usuario.
   * @param $configuration
   */
  private function obtenerSegundosACompensar($sesion) {

      $dateahora = new DateTime('NOW');

      $dateuptime = new DateTime($sesion->getUptime());
      
      $diferenciaensegundos = $dateuptime->getTimestamp() - $dateahora->getTimestamp();

      error_log("Segundos a compensar: " . $diferenciaensegundos."\n", 3, $this->path_log);

      return $diferenciaensegundos;

    }

   /**
   * Obtiene el usuario que actualmente utiliza la pc.
   * @param $configuration
   */
  private function obtenerUsario($usernames) {

      $usuario = false;

      error_log("\n usernames =". print_r($usernames, true). "\n", 3, $this->path_log);

      foreach ($usernames as $s) {

         error_log("Buscando socio " . $s . " en bd\n", 3, $this->path_log);

          $c = new Criteria();
          $c->add(UsuarioPeer::USUARIO, $s);
          $ustaff = UsuarioPeer::doSelectOne($c);
         if ($ustaff != null) {
            error_log("Usuario staff. \n", 3, $this->path_log);
            exit();
         }

         $o = new Criteria();
         $o->add(SocioPeer::USUARIO, $s);
         $socio = SocioPeer::doSelectOne($o);

         if ($socio != null) {
             
             $usuario = $socio->getUsuario();
             error_log("Socio encontrado en db: " . $usuario . "\n", 3, $this->path_log);
             
         }
      }
      return $usuario;
    }

   /**
   * Obtiene la ip con la cual esta actualmente registrada la pc.
   * @param $configuration
   */
  private function obtenerIp($ips) {

      $ip = false;

      error_log("\n ips =". print_r($ips, true). "\n", 3, $this->path_log);

      foreach ($ips as $i) {

         error_log("Buscando ip " . $i . " en bd\n", 3, $this->path_log);

         $o = new Criteria();
         $o->add(ComputadoraPeer::IP, $i);
         $computadora = ComputadoraPeer::doSelectOne($o);

         if ($computadora != null) {
             
             $ip = $computadora->getIp();
             error_log("Ip encontrado en db: " . $ip . "\n", 3, $this->path_log);
             
         }
      }
      return $ip;
    }

     /**
     * Elimina la sesión y genera una entrada para el histórico además de actualizar los tiempos de sesión.
     * @param Sesion $sesion
     * @param int $ajuste Segundos de ajuste para compensar tiempo.
     * @return SesionHistorico Regresa el registro de sesion histórico que corresponde a la sesion eliminada
     */
     private function eliminaSesion_agente($sesion, $ajuste)
    {
            $path_log = '/var/log/mako/rest-sesiones-pc.log';

            $tlogin = $sesion->getFechaLogin(null);
            error_log("elimina sesion ajuste " . $ajuste. "\n", 3, $path_log);
            //Generamos el historico de sesion
            $h = new SesionHistorico();
            $h->setCentroId($sesion->getCentroId());
            $h->setSocioId($sesion->getSocioId());
            $h->setUsuario($sesion->getUsuario());
            $h->setIp($sesion->getIp());
            $h->setComputadoraId($sesion->getComputadoraId());
            $h->setTipoId($sesion->getTipoId());
            $h->setFechaLogin($sesion->getFechaLogin());
            $ahora = time() + $ajuste;
            error_log("elimina sesion ahora " . print_r($ahora,true). "\n", 3, $path_log);

            $transcurrido = abs($ahora - $tlogin->format('U'));

            $h->setFechaLogout($ahora);
            $h->setOcupados($transcurrido);
            $h->setSaldoInicial($sesion->getSaldo());

            //Vemos el tipo de sesion que se trata para restar o no su saldo
            $tipo_id = $sesion->getTipoId();

            if($tipo_id == sfConfig::get('app_sesion_default_id') || $tipo_id == sfConfig::get('app_sesion_multisesion_id'))
            {
                    //actualizamos el saldo de tiempo del socio
                    $socio = $sesion->getSocio();
                    $nsaldo = ($socio->getSaldo() - $transcurrido);
                    if($nsaldo < 0 ) $nsaldo = 0;
                    $socio->setSaldo($nsaldo);
                    $socio->save();
                    $h->setSaldoFinal($nsaldo);
            }
            else
            {
                  //Si la sesion es de no consumo el saldo final queda igual
                    $h->setSaldoFinal($sesion->getSaldo());
            }
            try {
                    $h->save();
                    $sesion->delete();
            }
            catch(Exception $ex)
            {
                    error_log("Error[SesionPeer]: al tratar de guardar sesion historica: ".$ex->getMessage(). "\n", 3, $path_log);
                    $sesion->delete();
            }
            return $h;
    }
}
