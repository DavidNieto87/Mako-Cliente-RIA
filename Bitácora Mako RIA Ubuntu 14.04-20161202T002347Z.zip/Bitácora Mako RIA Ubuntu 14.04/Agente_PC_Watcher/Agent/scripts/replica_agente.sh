#!/bin/bash

#forma de uso: ./replica_agente.sh alias_centro
echo "Alias del centro a replicar: $1"

valid_ip()
{
local  ip=$1
local  stat=1

if [[ $ip =~ ^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$ ]]; then
    OIFS=$IFS
    IFS='.'
    ip=($ip)
    IFS=$OIFS
    [[ ${ip[0]} -le 255 && ${ip[1]} -le 255 \
        && ${ip[2]} -le 255 && ${ip[3]} -le 255 ]]
    stat=$?
fi

return $stat
}



#obteniendo la ip del centro en base a su alias
ip_centro=`psql -P "tuples_only" -U postgres mako -h 10.250.0.38 -c "select ip from centro where alias = '${1}'"`
ip_centro="$(echo -e "${ip_centro}" | tr -d '[[:space:]]')"

#creando la columna en la base de datos
psql -U postgres -h ${ip_centro} mako -c "ALTER TABLE sesion ADD COLUMN uptime timestamp without time zone"

#se crean carpetas y se copia la informacion al servidor centro
sshpass -p "3n0v4!!!" ssh -o StrictHostKeyChecking=no ${ip_centro} 'mkdir -p /var/www/Mako/apps/frontend/modules/restpcwatcher/actions'

sshpass -p "3n0v4!!!" scp ../archivos_mako/model/* ${ip_centro}:/var/www/Mako/lib/model/
sshpass -p "3n0v4!!!" scp ../archivos_mako/restpcwatcher/actions/* ${ip_centro}:/var/www/Mako/apps/frontend/modules/restpcwatcher/actions/
sshpass -p "3n0v4!!!" scp ../archivos_mako/task/* ${ip_centro}:/var/www/Mako/lib/task/

#dando de baja los crontabs de pc-watcher anteriores (falta volverlo sshpass)
crontab -l|grep -v 'mako:pcs-watcher'|crontab

#dando de alta el nuevo cron para pc-watcher en mako (falta volverlo sshpass)
(crontab -l 2>/dev/null; echo "*/5 20-22 * * 1-7 /usr/bin/php /var/www/mako/Mako/symfony mako:pcs-sesiones-activas") | crontab -


rm destfile.txt
for ip in `psql -U postgres mako -h 10.250.0.38 -c "select co.ip from computadora co inner join centro ce on co.centro_id = ce.id where ce.alias = '$1' and substring(co.ip,length(co.ip)-1,2) <> '98' and substring(co.ip,length(co.ip)-1,2) <> '99' order by co.ip;"
;"`
do
if valid_ip $ip; then echo "root@"$ip >> destfile.txt | printf '%s\nescribiendo ip-> '$ip' en archivo%s\n'; fi
done
