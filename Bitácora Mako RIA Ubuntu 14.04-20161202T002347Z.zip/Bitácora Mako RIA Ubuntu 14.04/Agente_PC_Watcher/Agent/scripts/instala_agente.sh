#!/bin/bash

#modo de ejecucion: ./instala_agente.sh
echo "Iniciando"

#while read dest
for i in `cat destfile.txt`;
do
  echo "Copiando en "$i
  sshpass -p "3n0v4!!!" ssh -o StrictHostKeyChecking=no $i 'mkdir -p /var/www/'
  sshpass -p "3n0v4!!!" ssh -o StrictHostKeyChecking=no $i 'mkdir /var/www/agente-pcwatcher/'
  sshpass -p "3n0v4!!!" ssh -o StrictHostKeyChecking=no $i 'mkdir /var/www/agente-pcwatcher/install'
  sshpass -p "3n0v4!!!" ssh -o StrictHostKeyChecking=no $i 'mkdir /var/www/agente-pcwatcher/target'


  echo "Se crearon carpetas en  "$i
  sshpass -p "3n0v4!!!" scp ./* $i:/var/www/agente-pcwatcher/install/
  sshpass -p "3n0v4!!!" scp ../target/Agent-1.0-SNAPSHOT-jar-with-dependencies.jar $i:/var/www/agente-pcwatcher/target/

  echo "Se copiaron archivos a carpetas en  "$i
  sshpass -p "3n0v4!!!" ssh -o StrictHostKeyChecking=no $i '/var/www/agente-pcwatcher/install/install3.sh $1'

done

echo "Finalizando"
