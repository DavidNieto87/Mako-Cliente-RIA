/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.enova.agent;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class Agent {

    public static final String Windows = "Windows";
    public static final String Mac = "Mac";
    public static final String Linux = "Linux";

    public static void main(String[] args) {
        try {
            Date date = new Date();
            SimpleDateFormat formatFecha = new SimpleDateFormat("dd-MM-yyyy");
            SimpleDateFormat formatHora = new SimpleDateFormat("hh:mm:ss");
            Runtime rt = Runtime.getRuntime();
            String[] cmd = {
                "/bin/sh",
                "-c",
                "who | cut -d' ' -f1|sort|uniq"
            };
            //windows echo %username%
            Process proc = rt.exec(cmd);
            String salida = "";
            InputStreamReader ost = new InputStreamReader(proc.getInputStream());
            BufferedReader br = new BufferedReader(ost);
            String line = "";
            while ((line = br.readLine()) != null) {
                salida += line + "\n";
            }
            int exitVal = proc.waitFor();
//            System.out.println("Sistema Operativo: --" + Agent.getOperativeSystem() + "--" + formatFecha.format(date) + "--" + formatHora.format(date) + "--");
//            System.out.println("Salida del proceso: \n" + salida);

            JSONParser parser = new JSONParser();

            Client client = Client.create();

            WebResource webResource = client
                    .resource("http://dev.robert.biocheck/index.php/api/v1/mako/agent?os=" + Agent.getOperativeSystem() + "&hora=" + formatHora.format(date) + "&fecha=" + formatFecha.format(date));
            ClientResponse response = webResource.accept("application/json")
                    .get(ClientResponse.class);

            if (response.getStatus() != 200) {
                throw new RuntimeException("Failed : HTTP error code : "
                        + response.getStatus());
            }

            String output = response.getEntity(String.class);
            JSONObject obj = (JSONObject) parser.parse(output);
//            System.out.println("sistema operativo:" + obj.get("sistema operativo"));
//            System.out.println("Output from Server .... \n");
//            System.out.println(output);

        } catch (Exception e) {
//            System.out.println("Entre a la excepcion...");
            e.printStackTrace();

        }
    }

    public static String getOperativeSystem() {
        String os = System.getProperty("os.name");
        //String os= "Windows 2000";
        if (os.contains(" ")) {
            int index = os.indexOf(" ");
            os = os.substring(0, index);
        }
        return os;
    }
}
