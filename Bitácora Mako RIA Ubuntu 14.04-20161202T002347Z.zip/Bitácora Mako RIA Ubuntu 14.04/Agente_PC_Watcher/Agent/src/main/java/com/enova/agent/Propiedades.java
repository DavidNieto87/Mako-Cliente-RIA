package com.enova.agent;

import com.enova.so.IOperatingSystem;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Clase encargada de la manipulacion del archivo de propiedades de la
 * aplicacion
 *
 * @version 1.0
 * @author roberto.monroy
 */
public class Propiedades {

    private Properties propiedades = null;
    private FileWriter out = null;
    private String path = null;
    IOperatingSystem op = null;

    public Propiedades(String SistemaOperativo) throws IOException {
        propiedades = new Properties();
        this.path = getPath(SistemaOperativo);
        checkConfigFile(this.path);
        //se crea una instancia a la clase Properties
        cargarProperties(this.path);
        //out = new FileWriter(path + "/config.properties");
    }

    /**
     * Obtencion de las propiedades del archivo de configuracion
     *
     * @return Objeto de tipo properties el cual contiene un arreglo asociativo
     * con las propiedades extraidas
     * @throws IOException Ocurre si no se puede acceder al archivo de
     * configuracion
     */
    public Properties getProperties() throws IOException {
        this.cargarProperties(this.path);
        if (!propiedades.isEmpty()) {
            return propiedades;
        } else {//sino  retornara NULL
            return null;
        }
    }

    public boolean setProperty(String key, String value) throws IOException {
        out = new FileWriter(path + "/config.properties");
        propiedades.setProperty(key, value);
        propiedades.store(out, null);
        out.close();
        return true;
    }

    public boolean createDefaultProperties(String path) throws IOException {
        out = new FileWriter(path + "/config.properties");
        propiedades.setProperty("retry", "5000");
        propiedades.setProperty("threads", "5");
        propiedades.setProperty("url", "localhost:8000");
        propiedades.store(out, null);
        out.close();
        return true;
    }

    private void checkConfigFile(String path) throws IOException {
        File f = new File(path + "/config.properties");
        if (!f.exists() && !f.isDirectory()) {
            System.out.println("No existe el direcorio y sera creado con datos por default...");
            f.createNewFile();
            createDefaultProperties(path);
        } else {
            System.out.println("Existe el archivo y se cargaran las propiedades de este...");
            cargarProperties(path);
        }

    }

    private void cargarProperties(String path) throws IOException {
        System.out.println("Accediendo al archivo:---> " + path + "/config.properties");
        propiedades.load(new FileReader(path + "/config.properties"));
        System.out.println("----Url: " + propiedades.getProperty("url"));
        System.out.println("----Retry: " + propiedades.getProperty("retry"));
        System.out.println("----Threads: " + propiedades.getProperty("threads"));
    }

    private String getPath(String sistemaOperativo) {
        String clase = Main.getOperationSystem(sistemaOperativo);
        try {
            op = (IOperatingSystem) Propiedades.class.getClassLoader().loadClass("com.enova.so." + clase).newInstance();
            System.out.println("path del archivo de configuracion-> " + op.getConfigPath());
            return op.getConfigPath();
        } catch (Exception ex) {
            Logger.getLogger(Propiedades.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "";
    }
}
